# -*- coding: utf-8 -*-
import os, sys
if '_mod_path' not in globals() or not _mod_path:
    _mod_path = os.path.realpath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))
    if _mod_path not in sys.path:
        sys.path.insert(0, _mod_path)
from etc.config.fit_param_utils import params_for_bins, params_with_updates

#############################################################
########## General settings
#############################################################
# EA reference: https://indico.cern.ch/event/1204277/contributions/5064356/attachments/2538496/4369369/CutBasedPhotonID_20221031.pdf

# baseline selection shared by all branches (keep trailing && for concatenation)
baseline_cut = (
    '(el_pt > 7) &&'
    '(abs(el_sc_eta) < 2.5) &&'
    '(abs(el_dz) < 1.0) &&'
    '(abs(el_dxy) < 0.5) &&'
)


# probe preselection (moved from old flags)
probe_preselection_cut = (
    '(('
    + baseline_cut +
    '(el_sc_et > 10) && ('
    '    (abs(el_sc_eta) < 0.8   && el_hzzMVA > 0.3527)'
    ' || (abs(el_sc_eta) >= 0.8  && abs(el_sc_eta) < 1.479 && el_hzzMVA > 0.2601)'
    ' || (abs(el_sc_eta) >= 1.479 && el_hzzMVA > -0.4954)'
    ' )'
    '&& ( (passHltEle23Ele12CaloIdLTrackIdLIsoVLLeg2 == 1 && el_hltE23E12leg2_dR < 0.3 && pair_lead_el_sc_et > 15 ) || (passHltEle23Ele12CaloIdLTrackIdLIsoVLLeg1L1match == 1 && el_hltE23E12leg1_dR < 0.3 && pair_lead_el_sc_et > 25 ) || (passHltEle30WPTightGsf == 1 && el_hltE30single_dR < 0.3 && pair_lead_el_sc_et > 35))'
    ') || ('
    + baseline_cut +
    '(el_sc_et < 10) && ('
    '    (abs(el_sc_eta) < 0.8   && el_hzzMVA > 0.9267)'
    ' || (abs(el_sc_eta) >= 0.8  && abs(el_sc_eta) < 1.479 && el_hzzMVA > 0.9138)'
    ' || (abs(el_sc_eta) >= 1.479 && el_hzzMVA > 0.9683)'
    ' )'
    '&& ( (passHltEle23Ele12CaloIdLTrackIdLIsoVLLeg2 == 1 && el_hltE23E12leg2_dR < 0.3 && pair_lead_el_sc_et > 15 ) || (passHltEle23Ele12CaloIdLTrackIdLIsoVLLeg1L1match == 1 && el_hltE23E12leg1_dR < 0.3 && pair_lead_el_sc_et > 25 ) || (passHltEle30WPTightGsf == 1 && el_hltE30single_dR < 0.3 && pair_lead_el_sc_et > 35))'
    '))'
)

# flag to be Tested
flags = {
    'hza_elminiIso0p15_nongap_2025_sf': '(el_miniPFRelIso_all < 0.15)',
}

# /eos/cms/store/group/phys_egamma/ec/nkasarag/EGM_comm/TnP_samples/2022/sim/DY_NLO/merged_Run3Summer22MiniAODv4-130X_mcRun3_2022_realistic_v5-v2.root
baseOutDir = '/eos/home-p/pelai/HZa/root_TnP/'

#############################################################
########## samples definition  - preparing the samples
#############################################################
### samples are defined in etc/inputs/tnpSampleDef.py
### not: you can setup another sampleDef File in inputs
import etc.inputs.tnpSampleDef as tnpSamples
tnpTreeDir = 'tnpEleTrig'

samplesDef = {
        'data'  : tnpSamples.Run3_2025_ele['Data_2025'].clone(),
        'mcNom' : tnpSamples.Run3_2025_ele['DY_MC_LO_2025'].clone(),
        'tagSel': tnpSamples.Run3_2025_ele['DY_MC_LO_2025'].clone(),
        'mcAlt': tnpSamples.Run3_2025_ele['DY_MC_NLO_2025'].clone(),
    }
## can add data sample easily
# samplesDef['data'].add_sample( tnpSamples.Run3_2025['Data_2025D'] )
# samplesDef['data'].add_sample( tnpSamples.Run3_2025['Data_2025E'] )
# samplesDef['data'].add_sample( tnpSamples.Run3_2025['Data_2025F'] )
# samplesDef['data'].add_sample( tnpSamples.Run3_2025['Data_2025G'] )
# samplesDef['data'].add_sample( tnpSamples.Run3_2025['Data_2025H'] )
# samplesDef['data'].add_sample( tnpSamples.Run3_2025['Data_2025I'] )


## can add data sample easily
# samplesDef['data'].add_sample(tnpSamples.Run3_124X_PromptReco2022G['data_Run2022G'].clone()) 
## some sample-based cuts... general cuts defined here after
## require mcTruth on MC DY samples and additional cuts
## all the samples MUST have different names (i.e. sample.name must be different for all)
## if you need to use 2 times the same sample, then rename the second one
#samplesDef['data'  ].set_cut('run >= 273726')
samplesDef['data' ].set_tnpTree(tnpTreeDir)
if not samplesDef['mcNom' ] is None: samplesDef['mcNom' ].set_tnpTree(tnpTreeDir)
if not samplesDef['mcAlt' ] is None: samplesDef['mcAlt' ].set_tnpTree(tnpTreeDir)
if not samplesDef['tagSel'] is None: samplesDef['tagSel'].set_tnpTree(tnpTreeDir)

if not samplesDef['mcNom' ] is None: samplesDef['mcNom' ].set_mcTruth()
if not samplesDef['mcAlt' ] is None: samplesDef['mcAlt' ].set_mcTruth()
if not samplesDef['tagSel'] is None: samplesDef['tagSel'].set_mcTruth()
if not samplesDef['tagSel'] is None:
    samplesDef['tagSel'].rename('mcAltSel_DY_MC_LO_2025')
    samplesDef['tagSel'].set_cut('tag_Ele_pt > 40 && abs(tag_sc_eta) < 2.17 && (tag_Ele_q + el_q) == 0')

## set MC weight, simple way (use tree weight) 
# weightName = 'totWeight'
# if not samplesDef['mcNom' ] is None: samplesDef['mcNom' ].set_weight(weightName)
# if not samplesDef['mcAlt' ] is None: samplesDef['mcAlt' ].set_weight(weightName)
# if not samplesDef['tagSel'] is None: samplesDef['tagSel'].set_weight(weightName)

## set MC weight, can use several pileup rw for different data taking 
# mcNom_puFile = '/eos/cms/store/group/phys_egamma/ec/tnpTuples/Prompt2023/pileupReweightingFiles/preBPIX/DY_madgraph_pho.pu.puTree.root'
# mcAlt_puFile = '/eos/cms/store/group/phys_egamma/ec/tnpTuples/Prompt2023/pileupReweightingFiles/preBPIX/DY_amcatnloext_pho.pu.puTree.root'
weightName = 'totWeight'   ## HZa: in-tree totWeight = weight(gen)*PUweight (was stale 2023 friend)
if not samplesDef['mcNom' ] is None: samplesDef['mcNom' ].set_weight(weightName)
if not samplesDef['mcAlt' ] is None: samplesDef['mcAlt' ].set_weight(weightName)
if not samplesDef['tagSel'] is None: samplesDef['tagSel'].set_weight(weightName)
# if not samplesDef['mcNom' ] is None: samplesDef['mcNom' ].set_puTree(mcNom_puFile)
# if not samplesDef['mcAlt' ] is None: samplesDef['mcAlt' ].set_puTree(mcAlt_puFile)
# if not samplesDef['tagSel'] is None: samplesDef['tagSel'].set_puTree(mcNom_puFile)

#############################################################
########## bining definition  [can be nD bining]
#############################################################
biningDef = [
   { 'var' : 'el_sc_eta' , 'type': 'float', 'bins': [-2.5,-2.0,-1.566,-0.8, 0.0, 0.8, 1.566, 2.0, 2.5] },
   { 'var' : 'el_et' , 'type': 'float', 'bins': [7,15,20,35,50,100,500] },
]

#############################################################
########## Cuts definition for all samples
#############################################################
### cut
cutBase   = 'tag_Ele_pt > 40 && abs(tag_sc_eta) < 2.17 && (tag_Ele_q + el_q) == 0 &&' + probe_preselection_cut

# can add addtionnal cuts for some bins (first check bin number using tnpEGM --checkBins)
additionalCuts = { 
   0 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   1 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   2 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   3 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   4 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   5 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   6 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   7 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   8 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   9 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
}

#### or remove any additional cut (default)
additionalCuts = None

#############################################################
########## fitting params to tune fit by hand if necessary
#############################################################
tnpParNomFit = [
    "meanP[-0.0,-5.0,5.0]","sigmaP[0.9,0.5,5.0]",
    "meanF[-0.0,-5.0,5.0]","sigmaF[0.9,0.5,5.0]",
    "acmsP[65.,45.,90.]","betaP[0.05,0.005,0.10]","gammaP[0.1, -2, 2]","peakP[87.0,82.0,90.0]",
    "acmsF[65.,45.,90.]","betaF[0.05,0.005,0.10]","gammaF[0.1, -2, 2]","peakF[87.0,82.0,90.0]",
    ]

# # 15
# tnpParNomFit = [
#     "meanP[-0.0,-5.0,5.0]","sigmaP[0.9,0.5,5.0]",
#     "meanF[-0.0,-5.0,5.0]","sigmaF[1.0,0.0,3.0]",
#     "acmsP[60.,50.,80.]","betaP[0.05,0.01,0.08]","gammaP[0.1, -2, 2]","peakP[87.0,82.0,90.0]",
#     "acmsF[60.,50.,70.]","betaF[0.05,0.05,0.07]","gammaF[0.01, -2, 2]","peakF[87.0,82.0,90.0]",
#     ]

# # 4
# tnpParNomFit = [
#     "meanP[-0.0,-5.0,5.0]","sigmaP[0.9,0.5,5.0]",
#     "meanF[0.2,0.1,5.0]","sigmaF[1.5]",
#     "acmsP[60.,50.,80.]","betaP[0.05,0.01,0.08]","gammaP[0.1, -2, 2]","peakP[87.0,82.0,90.0]",
#     "acmsF[60.,40.,80.]","betaF[0.05,0.01,0.08]","gammaF[0.01, -2, 0.1]","peakF[87.0,82.0,90.0]",
#     ]
# print("DEBUG tnpParNomFit =", tnpParNomFit)

tnpParAltSigFit = [
    "meanP[-0.0,-5.0,5.0]","sigmaP[1,0.7,6.0]","alphaP[2.0,1.2,3.5]" ,'nP[3,-5,5]',"sigmaP_2[1.5,0.5,6.0]","sosP[1,0.5,5.0]",
    "meanF[-0.0,-5.0,5.0]","sigmaF[2,0.7,8.0]","alphaF[2.0,1.2,3.5]",'nF[3,0,5]',"sigmaF_2[2.0,0.5,6.0]","sosF[1,0.5,5.0]",
    "acmsP[65.,45.,90.]","betaP[0.04,0.005,0.08]","gammaP[0.08, 0.002, 1.5]","peakP[89.0,82.0,90.0]",
    "acmsF[65.,45.,90.]","betaF[0.04,0.005,0.08]","gammaF[0.08, 0.002, 1.5]","peakF[89.0,82.0,90.0]",
    ]
     
tnpParAltBkgFit = [
    "meanP[-0.0,-5.0,5.0]","sigmaP[0.9,0.5,5.0]",
    "meanF[-0.0,-5.0,5.0]","sigmaF[0.9,0.5,5.0]",
    "alphaP[0.,-5.,5.]",
    "alphaF[0.,-5.,5.]",
    ]


tnpParAltSigBkgFit = [
  'meanP[-0.0, -5.0, 5.0]',
  'meanF[-0.0, -5.0, 5.0]',
  'sigmaP[0.5, 0.1, 2.0]',
  'sigmaF[0.5, 0.1, 2.0]',
  'sigmaP_2[0.5, 0.1, 2.0]',
  'sigmaF_2[0.5, 0.1, 3.0]',
  'sosP[0.10, 0.0, 1.0]',
  'sosF[0.12, 0.0, 1.0]',
  'alphaP[2.0, 1.4, 3.5]', 'nP[0.4, 0.0, 1.5]',
  'alphaF[2.0, 1.4, 3.5]', 'nF[0.4, 0.0, 1.5]',
  'alphaP_2[-0.012, -1, 0]',
  'alphaF_2[-0.014, -1, 0.05]',
]
tnpParAltSigBkgFitByBin = {
    6: params_with_updates(
        tnpParAltSigBkgFit,
        'alphaF_2[-0.014, -1, 0.]',
    ),
}

# ## 06
# tnpParAltSigBkgFit = [
#   'meanP[-0.0, -5.0, 5.0]',
#   'meanF[-0.0, -5.0, 5.0]',
#   'sigmaP[0.5, 0.1, 2.0]',
#   'sigmaF[0.5, 0.1, 2.0]',
#   'sigmaP_2[0.5, 0.1, 2.0]',
#   'sigmaF_2[0.5, 0.1, 3.0]',
#   'sosP[0.10, 0.0, 1.0]',
#   'sosF[0.12, 0.0, 1.0]',
#   'alphaP[2.0, 1.4, 3.5]', 'nP[0.4, 0.0, 1.5]',
#   'alphaF[2.0, 1.4, 3.5]', 'nF[0.4, 0.0, 1.5]',
#   'alphaP_2[-0.012, -1, 0]',
#   'alphaF_2[-0.014, -1, 0.]',
# ]

tnpParNomFitByBin = params_for_bins(
    tnpParNomFit,
    (1, 14),
    "meanP[-25.0,-40.0,5.0]",
    "sigmaP[7.0,2.0,16.0]",
    "acmsP[88.,65.,105.]",
    "betaP[0.025,0.001,0.08]",
    "gammaP[0.04,-0.1,0.8]",
    "peakP[87.0,82.0,90.0]",
)
# bins 18-21 (et 20-35 central) PASSING: base pass bkg CMSShape turn-on acmsP rails
# at upper bound 90 (Z peak) → bkg eats the signal peak (nBkgP 過大). Pin pass bkg
# turn-on (acmsP/betaP/peakP 常數) 讓 signal 取峰,只放 meanP/sigmaP。(failing 留 base;
# failing 低質量 shoulder 屬 template 限制不深調。)
tnpParNomFitByBin.update(params_for_bins(
    tnpParNomFit,
    (18, 19, 20, 21),
    "meanP[0.0,-2.5,2.5]",
    "sigmaP[1.3,0.5,3.5]",
    "acmsP[60.0]",
    "betaP[0.05]",
    "gammaP[0.05,0.0,0.5]",
    "peakP[87.0]",
))

tnpParAltSigFitByBin = {
    18: params_with_updates(
        tnpParAltSigFit,
        "meanP[-0.6,-5.0,4.0]",
        "sigmaP[1.8,0.7,4.5]",
        "sigmaP_2[1.0,0.4,3.5]",
        "alphaP[1.6,0.6,4.5]",
        "nP[1.0,-2.0,8.0]",
        "sosP[0.6,0.0,2.5]",
        "meanF[-1.8,-7.0,3.0]",
        "sigmaF[4.2,1.2,9.0]",
        "sigmaF_2[2.2,0.5,7.0]",
        "alphaF[1.1,0.4,4.5]",
        "nF[0.3,-1.0,8.0]",
        "sosF[1.6,0.1,5.0]",
        "acmsP[55.,38.,72.]",
        "betaP[0.018,0.001,0.05]",
        "gammaP[0.035,0.001,0.7]",
        "acmsF[55.,38.,72.]",
        "betaF[0.018,0.001,0.05]",
        "gammaF[0.035,0.001,0.7]",
    ),
    21: params_with_updates(
        tnpParAltSigFit,
        "meanP[-0.8,-6.0,5.0]",
        "sigmaP[3.4,0.8,8.0]",
        "sigmaP_2[1.6,0.4,6.5]",
        "alphaP[1.6,0.6,4.5]",
        "nP[1.0,-2.0,8.0]",
        "sosP[1.1,0.0,5.5]",
        "meanF[-1.8,-7.0,3.0]",
        "sigmaF[4.5,1.2,9.0]",
        "sigmaF_2[2.4,0.5,7.5]",
        "alphaF[1.1,0.4,4.5]",
        "nF[0.3,-1.0,8.0]",
        "sosF[1.8,0.1,5.5]",
        "acmsP[58.,40.,75.]",
        "betaP[0.02,0.001,0.06]",
        "gammaP[0.04,0.001,0.8]",
        "acmsF[58.,40.,75.]",
        "betaF[0.02,0.001,0.06]",
        "gammaF[0.04,0.001,0.8]",
    ),
    23: params_with_updates(
        tnpParAltSigFit,
        "meanP[-0.8,-6.0,5.0]",
        "sigmaP[8.0,2.0,18.0]",
        "sigmaP_2[5.0,1.0,15.0]",
        "sosP[4.0,0.2,14.0]",
        "acmsP[82.,55.,100.]",
        "betaP[0.03,0.001,0.08]",
        "gammaP[0.05,0.001,1.0]",
    ),
}
# bin16 (endcap eta -2.5~-2.0, et 20-35) PASSING: base DSCB core 太窄(sigmaP railed 1.0),
# 紅峰太尖太高、data 兩側 85-89 在紅之上。放寬 core sigmaP/sigmaP_2 + 鬆開 alphaP(原 railed 1.2)。
tnpParAltSigFitByBin[16] = params_with_updates(
    tnpParAltSigFit,
    # 強制寬 Gaussian core(抬 floor 防塌 1.0)+CB 轉折推遠(alphaP 大=更 Gaussian、非尖峰+尾)
    # +縮 sosP,治 status 303 的病態尖峰解。
    "sigmaP[2.6,1.8,5.5]",
    "sigmaP_2[3.6,2.2,8.0]",
    "sosP[0.6,0.0,2.0]",
    "alphaP[2.6,1.9,3.5]",
    "nP[2.0,0.5,6.0]",
)
tnpParAltSigFitByBin['bin18_el_sc_eta_m1p57Tom0p80_el_et_20p00To35p00'] = tnpParAltSigFitByBin[18]
tnpParAltSigFitByBin['bin21_el_sc_eta_0p80To1p57_el_et_20p00To35p00'] = tnpParAltSigFitByBin[21]

tnpParAltBkgFitByBin = params_for_bins(
    tnpParAltBkgFit,
    (1, 5),
    "meanP[-25.0,-40.0,5.0]",
    "sigmaP[7.0,2.0,16.0]",
    "alphaP[-0.03,-0.12,0.00]",
    "meanF[-2.0,-6.0,5.0]",
    "sigmaF[3.5,0.8,8.0]",
    "alphaF[-0.02,-0.10,0.02]",
)
tnpParAltBkgFitByBin.update({
    10: params_with_updates(
        tnpParAltBkgFit,
        "meanP[-0.6,-5.0,5.0]",
        "sigmaP[1.5,0.6,5.0]",
        "alphaP[-0.02,-0.20,0.03]",
        "meanF[-2.0,-5.0,1.0]",
        "sigmaF[2.5,0.8,5.0]",
        "alphaF[-0.08,-0.30,-0.005]",
    ),
    37: params_with_updates(
        tnpParAltBkgFit,
        "meanF[-1.0,-5.0,3.0]",
        "sigmaF[1.4,0.5,3.5]",
        "alphaF[-0.08,-0.30,-0.01]",
    ),
})

tnpParAltSigBkgFitByBin.update(params_for_bins(
    tnpParAltSigBkgFit,
    (1, 3, 5),
    'sigmaP[0.8, 0.2, 2.5]',
    'sigmaP_2[1.2, 0.1, 3.0]',
    'sosP[0.30, 0.0, 1.2]',
    'alphaP_2[-0.01, -0.08, 0.]',
    'sigmaF[0.8, 0.2, 2.5]',
    'sigmaF_2[1.0, 0.1, 3.0]',
    'sosF[0.25, 0.0, 1.2]',
    'alphaF_2[-0.01, -0.08, 0.]',
))
tnpParAltSigBkgFitByBin.update(params_for_bins(
    tnpParAltSigBkgFit,
    (34, 35, 37),
    'sigmaF[0.55, 0.2, 1.2]',
    'sigmaF_2[0.20, 0.08, 0.40]',
    'sosF[0.001, 0.0, 0.006]',
    'alphaF_2[-0.30, -0.80, -0.10]',
))
tnpParAltSigBkgFitByBin['bin34_el_sc_eta_m1p57Tom0p80_el_et_50p00To100p00'] = tnpParAltSigBkgFitByBin[34]
tnpParAltSigBkgFitByBin['bin35_el_sc_eta_m0p80To0p00_el_et_50p00To100p00'] = tnpParAltSigBkgFitByBin[35]
tnpParAltSigBkgFitByBin['bin37_el_sc_eta_0p80To1p57_el_et_50p00To100p00'] = tnpParAltSigBkgFitByBin[37]
