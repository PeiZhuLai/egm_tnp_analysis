# -*- coding: utf-8 -*-
import os, sys
if '_mod_path' not in globals() or not _mod_path:
    _mod_path = os.path.realpath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))
    if _mod_path not in sys.path:
        sys.path.insert(0, _mod_path)
from etc.config.fit_param_utils import params_with_updates

#############################################################
########## General settings
#############################################################
# EA reference: https://indico.cern.ch/event/1204277/contributions/5064356/attachments/2538496/4369369/CutBasedPhotonID_20221031.pdf

# baseline selection shared by all branches (keep trailing && for concatenation)
baseline_cut = (
    '(el_pt > 7) &&'
    '(abs(el_sc_eta) < 2.5) &&'
    '(abs(el_dz) < 1.0) &&'
    '(abs(el_dxy) < 0.5) &&'
)

# flag to be Tested
flags = {
    'hza_elid_nongap_2024_sf': (
        '('
        + baseline_cut +
        '('
        # ele Et > 10 region
        '((el_sc_et > 10) && ('
        '    (abs(el_sc_eta) < 0.8   && el_hzzMVA > 0.3527)'
        ' || (abs(el_sc_eta) >= 0.8  && abs(el_sc_eta) < 1.479 && el_hzzMVA > 0.2601)'
        ' || (abs(el_sc_eta) >= 1.479 && el_hzzMVA > -0.4954)'
        ' ))'
        ' || '
        # ele Et < 10 region
        '((el_sc_et < 10) && ('
        '    (abs(el_sc_eta) < 0.8   && el_hzzMVA > 0.9267)'
        ' || (abs(el_sc_eta) >= 0.8  && abs(el_sc_eta) < 1.479 && el_hzzMVA > 0.9138)'
        ' || (abs(el_sc_eta) >= 1.479 && el_hzzMVA > 0.9683)'
        ' ))'
        ')'
        ')'
    ),
}

# /eos/cms/store/group/phys_egamma/ec/nkasarag/EGM_comm/TnP_samples/2022/sim/DY_NLO/merged_Run3Summer22MiniAODv4-130X_mcRun3_2022_realistic_v5-v2.root
baseOutDir = '/eos/home-p/pelai/HZa/root_TnP/'

#############################################################
########## samples definition  - preparing the samples
#############################################################
### samples are defined in etc/inputs/tnpSampleDef.py
### not: you can setup another sampleDef File in inputs
import etc.inputs.tnpSampleDef as tnpSamples
tnpTreeDir = 'tnpEleIDs'

samplesDef = {
        'data'  : tnpSamples.Run3_2024_ele['Data_2024'].clone(),
        'mcNom' : tnpSamples.Run3_2024_ele['DY_MC_LO_2024'].clone(),
        'tagSel': tnpSamples.Run3_2024_ele['DY_MC_LO_2024'].clone(),
        'mcAlt': tnpSamples.Run3_2024_ele['DY_MC_NLO_2024'].clone(),
    }
## can add data sample easily
# samplesDef['data'].add_sample( tnpSamples.Run3_2024['Data_2024D'] )
# samplesDef['data'].add_sample( tnpSamples.Run3_2024['Data_2024E'] )
# samplesDef['data'].add_sample( tnpSamples.Run3_2024['Data_2024F'] )
# samplesDef['data'].add_sample( tnpSamples.Run3_2024['Data_2024G'] )
# samplesDef['data'].add_sample( tnpSamples.Run3_2024['Data_2024H'] )
# samplesDef['data'].add_sample( tnpSamples.Run3_2024['Data_2024I'] )


## can add data sample easily
# samplesDef['data'].add_sample(tnpSamples.Run3_124X_PromptReco2022G['data_Run2022G'].clone()) 
## some sample-based cuts... general cuts defined here after
## require mcTruth on MC DY samples and additional cuts
## all the samples MUST have different names (i.e. sample.name must be different for all)
## if you need to use 2 times the same sample, then rename the second one
#samplesDef['data'  ].set_cut('run >= 273726')
samplesDef['data' ].set_tnpTree(tnpTreeDir)
if not samplesDef['mcNom' ] is None: samplesDef['mcNom' ].set_tnpTree(tnpTreeDir)
if not samplesDef['mcAlt' ] is None: samplesDef['mcAlt' ].set_tnpTree(tnpTreeDir)
if not samplesDef['tagSel'] is None: samplesDef['tagSel'].set_tnpTree(tnpTreeDir)

if not samplesDef['mcNom' ] is None: samplesDef['mcNom' ].set_mcTruth()
if not samplesDef['mcAlt' ] is None: samplesDef['mcAlt' ].set_mcTruth()
if not samplesDef['tagSel'] is None: samplesDef['tagSel'].set_mcTruth()
if not samplesDef['tagSel'] is None:
    samplesDef['tagSel'].rename('mcAltSel_DY_MC_LO_2024')
    samplesDef['tagSel'].set_cut('tag_Ele_pt > 40 && abs(tag_sc_eta) < 2.17 && (tag_Ele_q + el_q) == 0')

## set MC weight, simple way (use tree weight) 
# weightName = 'totWeight'
# if not samplesDef['mcNom' ] is None: samplesDef['mcNom' ].set_weight(weightName)
# if not samplesDef['mcAlt' ] is None: samplesDef['mcAlt' ].set_weight(weightName)
# if not samplesDef['tagSel'] is None: samplesDef['tagSel'].set_weight(weightName)

## set MC weight, can use several pileup rw for different data taking 
# mcNom_puFile = '/eos/cms/store/group/phys_egamma/ec/tnpTuples/Prompt2023/pileupReweightingFiles/preBPIX/DY_madgraph_pho.pu.puTree.root'
# mcAlt_puFile = '/eos/cms/store/group/phys_egamma/ec/tnpTuples/Prompt2023/pileupReweightingFiles/preBPIX/DY_amcatnloext_pho.pu.puTree.root'
weightName = 'totWeight'   ## HZa: in-tree totWeight = weight(gen)*PUweight (was stale 2023 friend)
if not samplesDef['mcNom' ] is None: samplesDef['mcNom' ].set_weight(weightName)
if not samplesDef['mcAlt' ] is None: samplesDef['mcAlt' ].set_weight(weightName)
if not samplesDef['tagSel'] is None: samplesDef['tagSel'].set_weight(weightName)
# if not samplesDef['mcNom' ] is None: samplesDef['mcNom' ].set_puTree(mcNom_puFile)
# if not samplesDef['mcAlt' ] is None: samplesDef['mcAlt' ].set_puTree(mcAlt_puFile)
# if not samplesDef['tagSel'] is None: samplesDef['tagSel'].set_puTree(mcNom_puFile)

#############################################################
########## bining definition  [can be nD bining]
#############################################################
biningDef = [
   { 'var' : 'el_sc_eta' , 'type': 'float', 'bins': [-2.5,-2.0,-1.566,-0.8, 0.0, 0.8, 1.566, 2.0, 2.5] },
   { 'var' : 'el_et' , 'type': 'float', 'bins': [15,20,35,50,100] },
]

#############################################################
########## Cuts definition for all samples
#############################################################
### cut
cutBase   = 'tag_Ele_pt > 40 && abs(tag_sc_eta) < 2.17 && (tag_Ele_q + el_q) == 0'

# can add addtionnal cuts for some bins (first check bin number using tnpEGM --checkBins)
additionalCuts = { 
   0 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   1 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   2 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   3 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   4 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   5 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   6 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   7 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   8 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   9 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
}

#### or remove any additional cut (default)
additionalCuts = None

#############################################################
########## fitting params to tune fit by hand if necessary
#############################################################
tnpParNomFit = [
    "meanP[-0.0,-5.0,5.0]","sigmaP[0.9,0.5,5.0]",
    "meanF[-0.0,-5.0,5.0]","sigmaF[0.9,0.5,5.0]",
    "acmsP[65.,45.,90.]","betaP[0.05,0.005,0.10]","gammaP[0.1, -2, 2]","peakP[87.0,82.0,90.0]",
    "acmsF[65.,45.,90.]","betaF[0.05,0.005,0.10]","gammaF[0.1, -2, 2]","peakF[87.0,82.0,90.0]",
    ]
_nongap_nominal_fail_falling = (
    "acmsF[55.,35.,75.]",
    "betaF[0.02,0.001,0.08]",
    "gammaF[0.03,-0.2,0.4]",
)
_nongap_nominal_fail_turn68 = (
    "acmsF[68.,58.,78.]",
    "betaF[0.04,0.005,0.08]",
    "gammaF[0.03,-0.1,0.3]",
)
tnpParNomFitByBin = {
    0: params_with_updates(
        tnpParNomFit,
        "meanP[-2.2,-5.0,5.0]",
        "meanF[-2.5,-5.0,1.0]",
        "sigmaF[3.2,0.8,4.6]",
        "acmsP[75.,40.,100.]",
        "betaP[0.05,0.002,0.12]",
        "gammaP[0.08,0.002,2.]",
        *_nongap_nominal_fail_falling,
    ),
    1: params_with_updates(
        tnpParNomFit,
        "meanP[-1.2,-5.0,5.0]",
        "sigmaP[2.5,0.8,6.5]",
        "meanF[-2.5,-5.0,2.0]",
        "sigmaF[6.0,1.0,12.0]",
        "acmsP[75.,40.,100.]",
        "betaP[0.05,0.002,0.12]",
        "gammaP[0.08,0.002,2.]",
        *_nongap_nominal_fail_falling,
    ),
    2: params_with_updates(
        tnpParNomFit,
        "meanF[-2.5,-5.0,1.0]",
        "sigmaF[3.0,0.8,4.2]",
        *_nongap_nominal_fail_falling,
    ),
    3: params_with_updates(
        tnpParNomFit,
        "meanP[-0.4,-5.0,5.0]",
        "meanF[-2.2,-5.0,1.0]",
        "sigmaF[2.8,0.8,4.0]",
        "acmsP[75.,40.,100.]",
        "betaP[0.05,0.002,0.12]",
        "gammaP[0.08,0.002,2.]",
        *_nongap_nominal_fail_falling,
    ),
    5: params_with_updates(
        tnpParNomFit,
        "meanP[-0.6,-5.0,5.0]",
        "meanF[-2.2,-5.0,1.0]",
        "sigmaF[3.0,0.8,4.2]",
        "acmsP[75.,40.,100.]",
        "betaP[0.05,0.002,0.12]",
        "gammaP[0.08,0.002,2.]",
        *_nongap_nominal_fail_falling,
    ),
    6: params_with_updates(
        tnpParNomFit,
        "meanF[-2.2,-5.0,1.0]",
        "sigmaF[3.2,0.8,4.5]",
        *_nongap_nominal_fail_falling,
    ),
    8: params_with_updates(
        tnpParNomFit,
        "meanF[-2.2,-5.0,1.0]",
        "sigmaF[3.2,1.0,4.8]",
        "acmsF[62.,55.,70.]",
        "betaF[0.02,0.002,0.06]",
        "gammaF[0.02,-0.05,0.2]",
    ),
    9: params_with_updates(
        tnpParNomFit,
        "meanF[-2.2,-5.0,1.0]",
        "sigmaF[2.4,0.8,3.6]",
        *_nongap_nominal_fail_turn68,
    ),
    10: params_with_updates(
        tnpParNomFit,
        "meanF[-2.0,-5.0,1.0]",
        "sigmaF[2.4,0.8,3.6]",
        *_nongap_nominal_fail_turn68,
    ),
    11: params_with_updates(
        tnpParNomFit,
        "meanF[-1.8,-5.0,1.0]",
        "sigmaF[2.4,0.8,3.6]",
        *_nongap_nominal_fail_turn68,
    ),
    12: params_with_updates(
        tnpParNomFit,
        "meanF[-1.8,-5.0,1.0]",
        "sigmaF[2.4,0.8,3.6]",
        *_nongap_nominal_fail_turn68,
    ),
    13: params_with_updates(
        tnpParNomFit,
        "meanP[-0.2,-5.0,5.0]",
        "sigmaP[1.3,0.5,3.2]",
        "acmsP[92.,65.,115.]",
        "betaP[0.045,0.002,0.10]",
        "gammaP[0.06,-0.1,1.0]",
        "peakP[89.5,85.0,93.0]",
        "meanF[-2.0,-5.0,1.0]",
        "sigmaF[2.4,0.8,3.6]",
        *_nongap_nominal_fail_turn68,
    ),
    14: params_with_updates(
        tnpParNomFit,
        "meanP[-0.2,-5.0,5.0]",
        "sigmaP[1.3,0.5,3.2]",
        "acmsP[92.,65.,115.]",
        "betaP[0.045,0.002,0.10]",
        "gammaP[0.06,-0.1,1.0]",
        "peakP[89.5,85.0,93.0]",
        "meanF[-2.6,-5.0,1.0]",
        "sigmaF[2.0,0.7,3.2]",
        "acmsF[68.,56.,82.]",
        "betaF[0.04,0.003,0.10]",
        "gammaF[0.03,-0.1,0.5]",
    ),
    15: params_with_updates(
        tnpParNomFit,
        "meanP[-0.2,-5.0,5.0]",
        "sigmaP[1.4,0.5,3.5]",
        "acmsP[92.,65.,115.]",
        "betaP[0.045,0.002,0.10]",
        "gammaP[0.06,-0.1,1.0]",
        "peakP[89.5,85.0,93.0]",
        "meanF[-1.6,-5.0,2.0]",
        "sigmaF[2.8,0.8,5.0]",
        "acmsF[72.,55.,92.]",
        "betaF[0.04,0.003,0.12]",
        "gammaF[0.04,-0.1,0.8]",
    ),
    28: params_with_updates(
        tnpParNomFit,
        "meanP[1.0,-5.0,6.0]",
        "sigmaP[2.2,0.6,6.0]",
        "acmsP[95.,65.,125.]",
        "betaP[0.06,0.001,0.20]",
        "gammaP[0.05,-0.2,1.0]",
        "peakP[91.0,86.0,96.0]",
        "meanF[1.4,-5.0,5.0]",
        "sigmaF[2.0,0.5,5.0]",
        "acmsF[45.,40.,90.]",
        "betaF[0.005,0.0005,0.05]",
        "gammaF[-0.025,-0.40,0.20]",
        "peakF[85.0,80.0,92.0]",
    ),
}

# # 15
# tnpParNomFit = [
#     "meanP[-0.0,-5.0,5.0]","sigmaP[0.9,0.5,5.0]",
#     "meanF[-0.0,-5.0,5.0]","sigmaF[1.0,0.0,3.0]",
#     "acmsP[60.,50.,80.]","betaP[0.05,0.01,0.08]","gammaP[0.1, -2, 2]","peakP[87.0,82.0,90.0]",
#     "acmsF[60.,50.,70.]","betaF[0.05,0.05,0.07]","gammaF[0.01, -2, 2]","peakF[87.0,82.0,90.0]",
#     ]

# # 4
# tnpParNomFit = [
#     "meanP[-0.0,-5.0,5.0]","sigmaP[0.9,0.5,5.0]",
#     "meanF[0.2,0.1,5.0]","sigmaF[1.5]",
#     "acmsP[60.,50.,80.]","betaP[0.05,0.01,0.08]","gammaP[0.1, -2, 2]","peakP[87.0,82.0,90.0]",
#     "acmsF[60.,40.,80.]","betaF[0.05,0.01,0.08]","gammaF[0.01, -2, 0.1]","peakF[87.0,82.0,90.0]",
#     ]
# print("DEBUG tnpParNomFit =", tnpParNomFit)

tnpParAltSigFit = [
    "meanP[-0.0,-5.0,5.0]","sigmaP[1,0.7,6.0]","alphaP[2.0,1.2,3.5]" ,'nP[3,-5,5]',"sigmaP_2[1.5,0.5,6.0]","sosP[1,0.5,5.0]",
    "meanF[-0.0,-5.0,5.0]","sigmaF[2,0.7,8.0]","alphaF[2.0,1.2,3.5]",'nF[3,0,5]',"sigmaF_2[2.0,0.5,6.0]","sosF[1,0.5,5.0]",
    "acmsP[65.,45.,90.]","betaP[0.04,0.005,0.08]","gammaP[0.08, 0.002, 1.5]","peakP[89.0,82.0,90.0]",
    "acmsF[65.,45.,90.]","betaF[0.04,0.005,0.08]","gammaF[0.08, 0.002, 1.5]","peakF[89.0,82.0,90.0]",
    ]
_nongap_altsig_fail_falling = (
    "acmsF[55.,35.,75.]",
    "betaF[0.02,0.001,0.08]",
    "gammaF[0.03,0.001,0.80]",
)
_nongap_altsig_fail_turn68 = (
    "acmsF[68.,58.,78.]",
    "betaF[0.03,0.001,0.08]",
    "gammaF[0.03,0.001,0.80]",
)
tnpParAltSigFitByBin = {
    0: params_with_updates(
        tnpParAltSigFit,
        "meanP[-2.0,-5.0,5.0]",
        "sigmaP[4.0,1.0,6.0]",
        "sigmaP_2[1.5,0.4,4.0]",
        "alphaP[1.8,0.8,4.0]",
        "nP[0.8,0.0,6.0]",
        "sosP[1.5,0.0,4.0]",
        "meanF[-1.8,-4.0,2.0]",
        "sigmaF[3.2,1.0,5.0]",
        "sigmaF_2[0.7,0.3,2.0]",
        "alphaF[1.4,1.0,3.0]",
        "nF[0.4,0.0,3.0]",
        "sosF[0.5,0.0,2.0]",
        "acmsP[85.,25.,110.]",
        "betaP[0.04,0.001,0.10]",
        "gammaP[0.08,0.001,2.0]",
        *_nongap_altsig_fail_falling,
    ),
    1: params_with_updates(
        tnpParAltSigFit,
        "meanP[-1.4,-5.0,5.0]",
        "sigmaP[4.0,0.8,8.0]",
        "sigmaP_2[2.0,0.4,7.0]",
        "alphaP[1.8,0.8,4.0]",
        "nP[0.8,0.0,8.0]",
        "sosP[1.5,0.0,6.0]",
        "meanF[-2.0,-5.0,3.0]",
        "sigmaF[6.0,1.0,12.0]",
        "sigmaF_2[2.0,0.3,8.0]",
        "alphaF[1.8,0.8,4.0]",
        "nF[0.3,0.0,4.0]",
        "sosF[1.5,0.0,8.0]",
        "acmsP[85.,30.,115.]",
        "betaP[0.05,0.001,0.12]",
        "gammaP[0.06,0.001,1.2]",
        *_nongap_altsig_fail_falling,
    ),
    4: params_with_updates(
        tnpParAltSigFit,
        "meanP[-0.8,-5.0,5.0]",
        "sigmaP[3.5,0.8,7.0]",
        "sigmaP_2[1.8,0.4,6.0]",
        "sosP[1.3,0.0,5.0]",
        "meanF[-1.8,-5.0,3.0]",
        "sigmaF[5.0,1.0,10.0]",
        "sigmaF_2[1.5,0.3,7.0]",
        "alphaF[1.8,0.8,4.0]",
        "nF[0.3,0.0,4.0]",
        "sosF[1.2,0.0,7.0]",
        "acmsP[88.,40.,115.]",
        "betaP[0.05,0.001,0.12]",
        "gammaP[0.06,0.001,1.2]",
        *_nongap_altsig_fail_falling,
    ),
    7: params_with_updates(
        tnpParAltSigFit,
        "meanP[-1.0,-5.0,5.0]",
        "sigmaP[3.5,0.8,7.0]",
        "sigmaP_2[1.8,0.4,6.0]",
        "sosP[1.3,0.0,5.0]",
        "meanF[-1.8,-5.0,3.0]",
        "sigmaF[5.5,1.0,11.0]",
        "sigmaF_2[1.5,0.3,7.0]",
        "alphaF[1.8,0.8,4.0]",
        "nF[0.3,0.0,4.0]",
        "sosF[1.2,0.0,7.0]",
        "acmsP[85.,35.,115.]",
        "betaP[0.05,0.001,0.12]",
        "gammaP[0.06,0.001,1.2]",
        *_nongap_altsig_fail_falling,
    ),
    8: params_with_updates(
        tnpParAltSigFit,
        "meanP[-2.1,-5.0,5.0]",
        "sigmaP[4.0,1.5,8.0]",
        "sigmaP_2[2.0,0.5,8.0]",
        "alphaP[1.8,0.8,4.0]",
        "nP[1.0,0.0,8.0]",
        "sosP[1.5,0.2,6.0]",
        "meanF[-2.0,-5.0,5.0]",
        "sigmaF[7.0,1.5,12.0]",
        "sigmaF_2[1.0,0.3,8.0]",
        "alphaF[2.0,0.8,4.0]",
        "nF[1.0,0.0,8.0]",
        "sosF[2.5,0.2,10.0]",
        "acmsP[75.,35.,100.]",
        "betaP[0.04,0.002,0.12]",
        "gammaP[0.08,0.002,2.0]",
        "acmsF[75.,35.,100.]",
        "betaF[0.04,0.002,0.12]",
        "gammaF[0.08,0.002,2.0]",
    ),
    9: params_with_updates(
        tnpParAltSigFit,
        "meanF[-2.5,-5.0,1.0]",
        "sigmaF[3.5,1.2,5.5]",
        "sigmaF_2[0.8,0.3,2.0]",
        "alphaF[1.4,1.0,3.0]",
        "nF[0.4,0.0,3.0]",
        "sosF[1.2,0.0,3.0]",
        *_nongap_altsig_fail_turn68,
    ),
    10: params_with_updates(
        tnpParAltSigFit,
        "meanF[-2.0,-5.0,1.0]",
        "sigmaF[3.5,1.2,5.5]",
        "sigmaF_2[0.8,0.3,2.0]",
        "alphaF[1.4,1.0,3.0]",
        "nF[0.4,0.0,3.0]",
        "sosF[1.0,0.0,3.0]",
        *_nongap_altsig_fail_turn68,
    ),
    12: params_with_updates(
        tnpParAltSigFit,
        "meanP[-0.4,-5.0,5.0]",
        "sigmaP[2.0,0.7,6.0]",
        "sigmaP_2[1.6,0.4,5.0]",
        "sosP[1.3,0.0,5.0]",
        "meanF[-0.6,-5.0,5.0]",
        "sigmaF[3.5,0.8,8.0]",
        "sigmaF_2[1.5,0.3,6.0]",
        "alphaF[1.8,0.8,4.0]",
        "nF[0.3,0.0,4.0]",
        "sosF[2.0,0.0,8.0]",
        "acmsP[88.,40.,115.]",
        "betaP[0.05,0.001,0.12]",
        "gammaP[0.06,0.001,1.2]",
        "acmsF[90.,50.,120.]",
        "betaF[0.02,0.001,0.10]",
        "gammaF[0.02,0.001,1.0]",
    ),
    13: params_with_updates(
        tnpParAltSigFit,
        "meanP[-0.2,-5.0,5.0]",
        "sigmaP[3.2,1.0,7.0]",
        "sigmaP_2[2.6,0.6,7.0]",
        "sosP[1.8,0.2,6.0]",
        "acmsP[90.,60.,115.]",
        "betaP[0.045,0.001,0.12]",
        "gammaP[0.08,0.001,1.2]",
        "peakP[89.5,85.0,93.0]",
        "meanF[-2.2,-5.0,1.0]",
        "sigmaF[3.8,1.2,5.8]",
        "sigmaF_2[0.8,0.3,2.0]",
        "alphaF[1.4,1.0,3.0]",
        "nF[0.4,0.0,3.0]",
        "sosF[1.2,0.0,3.0]",
        *_nongap_altsig_fail_turn68,
    ),
    14: params_with_updates(
        tnpParAltSigFit,
        "meanF[-2.8,-5.0,1.0]",
        "sigmaF[3.5,1.2,5.5]",
        "sigmaF_2[0.8,0.3,2.0]",
        "alphaF[1.4,1.0,3.0]",
        "nF[0.4,0.0,3.0]",
        "sosF[1.2,0.0,3.0]",
        *_nongap_altsig_fail_turn68,
    ),
}
     
tnpParAltBkgFit = [
    "meanP[-0.0,-5.0,5.0]","sigmaP[0.9,0.5,5.0]",
    "meanF[-0.0,-5.0,5.0]","sigmaF[0.9,0.5,5.0]",
    "alphaP[0.,-5.,5.]",
    "alphaF[0.,-5.,5.]",
    ]
tnpParAltBkgFitByBin = {
    3: params_with_updates(
        tnpParAltBkgFit,
        "meanF[-1.0,-2.5,1.0]",
        "sigmaF[2.2,1.0,3.5]",
        "alphaF[-0.06,-0.15,-0.005]",
    ),
    4: params_with_updates(
        tnpParAltBkgFit,
        "meanP[-0.4,-5.0,5.0]",
        "sigmaP[1.3,0.8,4.0]",
        "alphaP[-0.03,-5.,5.]",
        "meanF[-1.0,-2.5,1.0]",
        "sigmaF[2.1,1.0,3.3]",
        "alphaF[-0.06,-0.15,-0.005]",
    ),
    5: params_with_updates(
        tnpParAltBkgFit,
        "meanP[-0.65,-5.0,5.0]",
        "sigmaP[1.5,0.8,4.5]",
        "alphaP[-0.04,-5.,5.]",
        "meanF[-1.1,-5.0,5.0]",
        "sigmaF[1.9,0.8,5.0]",
        "alphaF[-0.03,-5.,5.]",
    ),
    31: params_with_updates(
        tnpParAltBkgFit,
        "meanP[-0.8,-5.0,5.0]",
        "sigmaP[1.8,0.8,6.0]",
        "alphaP[-0.1,-5.,5.]",
        "meanF[0.3,-5.0,5.0]",
        "sigmaF[4.8,1.0,10.0]",
        "alphaF[0.1,-5.,5.]",
    ),
}


tnpParAltSigBkgFit = [
  'meanP[-0.0, -5.0, 5.0]',
  'meanF[-0.0, -5.0, 5.0]',
  'sigmaP[0.5, 0.1, 2.0]',
  'sigmaF[0.5, 0.1, 2.0]',
  'sigmaP_2[0.5, 0.1, 2.0]',
  'sigmaF_2[0.5, 0.1, 3.0]',
  'sosP[0.10, 0.0, 1.0]',
  'sosF[0.12, 0.0, 1.0]',
  'alphaP[2.0, 1.4, 3.5]', 'nP[0.4, 0.0, 1.5]',
  'alphaF[2.0, 1.4, 3.5]', 'nF[0.4, 0.0, 1.5]',
  'alphaP_2[-0.012, -1, 0]',
  'alphaF_2[-0.014, -1, 0.05]',
]
tnpParAltSigBkgFitByBin = {
    6: params_with_updates(
        tnpParAltSigBkgFit,
        'meanF[0.0, -3.0, 2.0]',
        'sigmaF[0.8, 0.2, 1.8]',
        'sigmaF_2[0.5, 0.1, 1.5]',
        'sosF[0.2, 0.0, 0.8]',
        'alphaF[2.2, 1.4, 3.5]',
        'nF[0.4, 0.0, 1.2]',
        'alphaF_2[-0.05, -0.2, -0.005]',
    ),
}

# ## 06
# tnpParAltSigBkgFit = [
#   'meanP[-0.0, -5.0, 5.0]',
#   'meanF[-0.0, -5.0, 5.0]',
#   'sigmaP[0.5, 0.1, 2.0]',
#   'sigmaF[0.5, 0.1, 2.0]',
#   'sigmaP_2[0.5, 0.1, 2.0]',
#   'sigmaF_2[0.5, 0.1, 3.0]',
#   'sosP[0.10, 0.0, 1.0]',
#   'sosF[0.12, 0.0, 1.0]',
#   'alphaP[2.0, 1.4, 3.5]', 'nP[0.4, 0.0, 1.5]',
#   'alphaF[2.0, 1.4, 3.5]', 'nF[0.4, 0.0, 1.5]',
#   'alphaP_2[-0.012, -1, 0]',
#   'alphaF_2[-0.014, -1, 0.]',
# ]
