# -*- coding: utf-8 -*-
import os, sys
if '_mod_path' not in globals() or not _mod_path:
    _mod_path = os.path.realpath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))
    if _mod_path not in sys.path:
        sys.path.insert(0, _mod_path)
from etc.config.fit_param_utils import params_for_bins, params_with_updates

#############################################################
########## General settings
#############################################################
# EA reference: https://indico.cern.ch/event/1204277/contributions/5064356/attachments/2538496/4369369/CutBasedPhotonID_20221031.pdf

# baseline selection shared by all branches (keep trailing && for concatenation)
baseline_cut = (
    '(el_pt > 7) &&'
    '(abs(el_sc_eta) < 2.5) &&'
    '(abs(el_dz) < 1.0) &&'
    '(abs(el_dxy) < 0.5) &&'
)


# probe preselection (moved from old flags)
probe_preselection_cut = (
    '(('
    + baseline_cut +
    '(el_sc_et > 10) && ('
    '    (abs(el_sc_eta) < 0.8   && el_hzzMVA > 0.3527)'
    ' || (abs(el_sc_eta) >= 0.8  && abs(el_sc_eta) < 1.479 && el_hzzMVA > 0.2601)'
    ' || (abs(el_sc_eta) >= 1.479 && el_hzzMVA > -0.4954)'
    ' )'
    '&& ( ((passHltEle23Ele12CaloIdLTrackIdLIsoVLLeg2 == 1 && el_hltE23E12leg2_dR < 0.3 && pair_lead_el_sc_et > 15 ) && (passHltEle23Ele12CaloIdLTrackIdLIsoVLLeg1L1match == 1) && el_hltE23E12leg1_dR < 0.3 && pair_lead_el_sc_et > 25 ) || (passHltEle30WPTightGsf == 1 && el_hltE30single_dR < 0.3 && pair_lead_el_sc_et > 35))'
    ') || ('
    + baseline_cut +
    '(el_sc_et < 10) && ('
    '    (abs(el_sc_eta) < 0.8   && el_hzzMVA > 0.9267)'
    ' || (abs(el_sc_eta) >= 0.8  && abs(el_sc_eta) < 1.479 && el_hzzMVA > 0.9138)'
    ' || (abs(el_sc_eta) >= 1.479 && el_hzzMVA > 0.9683)'
    ' )'
    '&& ( ((passHltEle23Ele12CaloIdLTrackIdLIsoVLLeg2 == 1 && el_hltE23E12leg2_dR < 0.3 && pair_lead_el_sc_et > 15 ) && (passHltEle23Ele12CaloIdLTrackIdLIsoVLLeg1L1match == 1) && el_hltE23E12leg1_dR < 0.3 && pair_lead_el_sc_et > 25 ) || (passHltEle30WPTightGsf == 1 && el_hltE30single_dR < 0.3 && pair_lead_el_sc_et > 35))'
    '))'
)

# flag to be Tested
flags = {
    'hza_elminiIso0p15_nongap_2024_sf': '(el_miniPFRelIso_all < 0.15)',
}

# /eos/cms/store/group/phys_egamma/ec/nkasarag/EGM_comm/TnP_samples/2022/sim/DY_NLO/merged_Run3Summer22MiniAODv4-130X_mcRun3_2022_realistic_v5-v2.root
baseOutDir = '/eos/home-p/pelai/HZa/root_TnP/'

#############################################################
########## samples definition  - preparing the samples
#############################################################
### samples are defined in etc/inputs/tnpSampleDef.py
### not: you can setup another sampleDef File in inputs
import etc.inputs.tnpSampleDef as tnpSamples
tnpTreeDir = 'tnpEleTrig'

samplesDef = {
        'data'  : tnpSamples.Run3_2024_ele['Data_2024'].clone(),
        'mcNom' : tnpSamples.Run3_2024_ele['DY_MC_NLO_2024'].clone(),
        'tagSel': tnpSamples.Run3_2024_ele['DY_MC_NLO_2024'].clone(),
        'mcAlt': tnpSamples.Run3_2024_ele['DY_MC_LO_2024'].clone(),
    }
## can add data sample easily
# samplesDef['data'].add_sample( tnpSamples.Run3_2024['Data_2024D'] )
# samplesDef['data'].add_sample( tnpSamples.Run3_2024['Data_2024E'] )
# samplesDef['data'].add_sample( tnpSamples.Run3_2024['Data_2024F'] )
# samplesDef['data'].add_sample( tnpSamples.Run3_2024['Data_2024G'] )
# samplesDef['data'].add_sample( tnpSamples.Run3_2024['Data_2024H'] )
# samplesDef['data'].add_sample( tnpSamples.Run3_2024['Data_2024I'] )


## can add data sample easily
# samplesDef['data'].add_sample(tnpSamples.Run3_124X_PromptReco2022G['data_Run2022G'].clone()) 
## some sample-based cuts... general cuts defined here after
## require mcTruth on MC DY samples and additional cuts
## all the samples MUST have different names (i.e. sample.name must be different for all)
## if you need to use 2 times the same sample, then rename the second one
#samplesDef['data'  ].set_cut('run >= 273726')
samplesDef['data' ].set_tnpTree(tnpTreeDir)
if not samplesDef['mcNom' ] is None: samplesDef['mcNom' ].set_tnpTree(tnpTreeDir)
if not samplesDef['mcAlt' ] is None: samplesDef['mcAlt' ].set_tnpTree(tnpTreeDir)
if not samplesDef['tagSel'] is None: samplesDef['tagSel'].set_tnpTree(tnpTreeDir)

if not samplesDef['mcNom' ] is None: samplesDef['mcNom' ].set_mcTruth()
if not samplesDef['mcAlt' ] is None: samplesDef['mcAlt' ].set_mcTruth()
if not samplesDef['tagSel'] is None: samplesDef['tagSel'].set_mcTruth()
if not samplesDef['tagSel'] is None:
    samplesDef['tagSel'].rename('mcAltSel_DY_MC_NLO_2024')
    samplesDef['tagSel'].set_cut('tag_Ele_pt > 40 && abs(tag_sc_eta) < 2.17 && (tag_Ele_q + el_q) == 0')

## set MC weight, simple way (use tree weight) 
# weightName = 'totWeight'
# if not samplesDef['mcNom' ] is None: samplesDef['mcNom' ].set_weight(weightName)
# if not samplesDef['mcAlt' ] is None: samplesDef['mcAlt' ].set_weight(weightName)
# if not samplesDef['tagSel'] is None: samplesDef['tagSel'].set_weight(weightName)

## set MC weight, can use several pileup rw for different data taking 
mcNom_puFile = '/eos/cms/store/group/phys_egamma/ec/tnpTuples/Prompt2023/pileupReweightingFiles/preBPIX/DY_madgraph_pho.pu.puTree.root'
mcAlt_puFile = '/eos/cms/store/group/phys_egamma/ec/tnpTuples/Prompt2023/pileupReweightingFiles/preBPIX/DY_amcatnloext_pho.pu.puTree.root'
weightName = 'weights_data_Run2023C.totWeight'
if not samplesDef['mcNom' ] is None: samplesDef['mcNom' ].set_weight(weightName)
if not samplesDef['mcAlt' ] is None: samplesDef['mcAlt' ].set_weight(weightName)
if not samplesDef['tagSel'] is None: samplesDef['tagSel'].set_weight(weightName)
if not samplesDef['mcNom' ] is None: samplesDef['mcNom' ].set_puTree(mcNom_puFile)
if not samplesDef['mcAlt' ] is None: samplesDef['mcAlt' ].set_puTree(mcAlt_puFile)
if not samplesDef['tagSel'] is None: samplesDef['tagSel'].set_puTree(mcNom_puFile)

#############################################################
########## bining definition  [can be nD bining]
#############################################################
biningDef = [
   { 'var' : 'el_sc_eta' , 'type': 'float', 'bins': [-2.5,-2.0,-1.566,-0.8, 0.0, 0.8, 1.566, 2.0, 2.5] },
   { 'var' : 'el_et' , 'type': 'float', 'bins': [7,15,20,35,50,100,500] },
]

#############################################################
########## Cuts definition for all samples
#############################################################
### cut
cutBase   = 'tag_Ele_pt > 40 && abs(tag_sc_eta) < 2.17 && (tag_Ele_q + el_q) == 0 &&' + probe_preselection_cut

# can add addtionnal cuts for some bins (first check bin number using tnpEGM --checkBins)
additionalCuts = { 
   0 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   1 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   2 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   3 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   4 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   5 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   6 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   7 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   8 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
   9 : 'sqrt( 2*event_met_pfmet*tag_Ele_pt*(1-cos(event_met_pfphi-tag_Ele_phi))) < 45',
}

#### or remove any additional cut (default)
additionalCuts = None

#############################################################
########## fitting params to tune fit by hand if necessary
#############################################################
tnpParNomFit = [
    "meanP[-0.0,-5.0,5.0]","sigmaP[0.9,0.5,5.0]",
    "meanF[-0.0,-5.0,5.0]","sigmaF[0.9,0.5,5.0]",
    "acmsP[65.,45.,90.]","betaP[0.05,0.005,0.10]","gammaP[0.1, -2, 2]","peakP[87.0,82.0,90.0]",
    "acmsF[65.,45.,90.]","betaF[0.05,0.005,0.10]","gammaF[0.1, -2, 2]","peakF[87.0,82.0,90.0]",
    ]

# # 15
# tnpParNomFit = [
#     "meanP[-0.0,-5.0,5.0]","sigmaP[0.9,0.5,5.0]",
#     "meanF[-0.0,-5.0,5.0]","sigmaF[1.0,0.0,3.0]",
#     "acmsP[60.,50.,80.]","betaP[0.05,0.01,0.08]","gammaP[0.1, -2, 2]","peakP[87.0,82.0,90.0]",
#     "acmsF[60.,50.,70.]","betaF[0.05,0.05,0.07]","gammaF[0.01, -2, 2]","peakF[87.0,82.0,90.0]",
#     ]

# # 4
# tnpParNomFit = [
#     "meanP[-0.0,-5.0,5.0]","sigmaP[0.9,0.5,5.0]",
#     "meanF[0.2,0.1,5.0]","sigmaF[1.5]",
#     "acmsP[60.,50.,80.]","betaP[0.05,0.01,0.08]","gammaP[0.1, -2, 2]","peakP[87.0,82.0,90.0]",
#     "acmsF[60.,40.,80.]","betaF[0.05,0.01,0.08]","gammaF[0.01, -2, 0.1]","peakF[87.0,82.0,90.0]",
#     ]
# print("DEBUG tnpParNomFit =", tnpParNomFit)

tnpParAltSigFit = [
    "meanP[-0.0,-5.0,5.0]","sigmaP[1,0.7,6.0]","alphaP[2.0,1.2,3.5]" ,'nP[3,-5,5]',"sigmaP_2[1.5,0.5,6.0]","sosP[1,0.5,5.0]",
    "meanF[-0.0,-5.0,5.0]","sigmaF[2,0.7,8.0]","alphaF[2.0,1.2,3.5]",'nF[3,0,5]',"sigmaF_2[2.0,0.5,6.0]","sosF[1,0.5,5.0]",
    "acmsP[65.,45.,90.]","betaP[0.04,0.005,0.08]","gammaP[0.08, 0.002, 1.5]","peakP[89.0,82.0,90.0]",
    "acmsF[65.,45.,90.]","betaF[0.04,0.005,0.08]","gammaF[0.08, 0.002, 1.5]","peakF[89.0,82.0,90.0]",
    ]
     
tnpParAltBkgFit = [
    "meanP[-0.0,-5.0,5.0]","sigmaP[0.9,0.5,5.0]",
    "meanF[-0.0,-5.0,5.0]","sigmaF[0.9,0.5,5.0]",
    "alphaP[0.,-5.,5.]",
    "alphaF[0.,-5.,5.]",
    ]


tnpParAltSigBkgFit = [
  'meanP[-0.0, -5.0, 5.0]',
  'meanF[-0.0, -5.0, 5.0]',
  'sigmaP[0.5, 0.1, 2.0]',
  'sigmaF[0.5, 0.1, 2.0]',
  'sigmaP_2[0.5, 0.1, 2.0]',
  'sigmaF_2[0.5, 0.1, 3.0]',
  'sosP[0.10, 0.0, 1.0]',
  'sosF[0.12, 0.0, 1.0]',
  'alphaP[2.0, 1.4, 3.5]', 'nP[0.4, 0.0, 1.5]',
  'alphaF[2.0, 1.4, 3.5]', 'nF[0.4, 0.0, 1.5]',
  'alphaP_2[-0.012, -1, 0]',
  'alphaF_2[-0.014, -1, 0.05]',
]
tnpParAltSigBkgFitByBin = {
    6: params_with_updates(
        tnpParAltSigBkgFit,
        'alphaF_2[-0.014, -1, 0.]',
    ),
}
tnpParAltSigBkgFitByBin.update(params_for_bins(
    tnpParAltSigBkgFit,
    (19, 20, 21),
    'sigmaF[0.35, 0.08, 2.4]',
    'sigmaF_2[1.0, 0.10, 3.0]',
    'sosF[0.06, 0.0, 0.4]',
    'alphaF[2.5, 1.0, 4.0]',
    'nF[1.0, 0.0, 2.5]',
    'alphaF_2[-0.015, -0.12, 0.02]',
))
# bin20 (et 20-35, FAILING altSigBkg): the failing leg is bimodal (a low-mass
# brems/FSR shoulder near m~78 plus the Z core at ~91). With the shared 19/20/21
# recipe the CB tail alphaF rails at its lower bound 1.0 (it wants a longer tail to
# reach the shoulder) and the fit blows up (edm~5e10). Give bin20 a dedicated
# recipe: lower the alphaF floor so the CB tail can extend, widen nF and the second
# Gaussian to absorb the shoulder, give meanF a little freedom, and constrain the
# exp-bkg slope. (bins 19/21 keep the shared recipe.)
tnpParAltSigBkgFitByBin[20] = params_with_updates(
    tnpParAltSigBkgFit,
    'meanF[-0.3, -3.0, 2.0]',
    'sigmaF[0.4, 0.1, 2.0]',
    'sigmaF_2[1.3, 0.3, 3.5]',
    'sosF[0.18, 0.0, 0.6]',
    'alphaF[1.8, 0.6, 4.0]',
    'nF[1.2, 0.0, 3.5]',
    'alphaF_2[-0.02, -0.1, 0.0]',
)

# ## 06
# tnpParAltSigBkgFit = [
#   'meanP[-0.0, -5.0, 5.0]',
#   'meanF[-0.0, -5.0, 5.0]',
#   'sigmaP[0.5, 0.1, 2.0]',
#   'sigmaF[0.5, 0.1, 2.0]',
#   'sigmaP_2[0.5, 0.1, 2.0]',
#   'sigmaF_2[0.5, 0.1, 3.0]',
#   'sosP[0.10, 0.0, 1.0]',
#   'sosF[0.12, 0.0, 1.0]',
#   'alphaP[2.0, 1.4, 3.5]', 'nP[0.4, 0.0, 1.5]',
#   'alphaF[2.0, 1.4, 3.5]', 'nF[0.4, 0.0, 1.5]',
#   'alphaP_2[-0.012, -1, 0]',
#   'alphaF_2[-0.014, -1, 0.]',
# ]

tnpParNomFitByBin = {}
tnpParNomFitByBin.update(params_for_bins(
    tnpParNomFit,
    (12,),
    "meanP[-1.5,-6.0,5.0]",
    "sigmaP[3.0,0.8,6.5]",
    "acmsP[78.,45.,95.]",
    "betaP[0.02,0.001,0.08]",
    "gammaP[0.04,-0.1,0.8]",
    "peakP[87.0,82.0,90.0]",
))
tnpParNomFitByBin.update(params_for_bins(
    tnpParNomFit,
    (17, 22),
    "meanP[-0.5,-5.0,5.0]",
    "sigmaP[2.0,0.8,5.0]",
    "meanF[-0.8,-5.0,3.0]",
    "sigmaF[2.2,0.8,5.5]",
    "acmsP[88.,70.,95.]",
    "betaP[0.03,0.001,0.08]",
    "gammaP[0.04,-0.1,0.6]",
))
tnpParNomFitByBin.update(params_for_bins(
    tnpParNomFit,
    (19, 20, 21),
    "meanP[-0.5,-5.0,5.0]",
    "sigmaP[2.0,0.8,5.0]",
    "acmsP[60.,40.,78.]",
    "betaP[0.02,0.001,0.06]",
    "gammaP[0.04,-0.1,0.8]",
))
tnpParNomFitByBin[37] = params_with_updates(
    tnpParNomFit,
    "meanF[-1.0,-5.0,3.0]",
    "sigmaF[1.8,0.5,5.5]",
    "acmsF[70.,45.,95.]",
    "betaF[0.04,0.001,0.08]",
    "gammaF[0.06,-0.2,0.8]",
)
# bins 16/18/23: passing-leg Z peak undershot (meanP stuck at 0 -> red spike slightly
# left of and below the data peak, overshooting the left shoulder). Give meanP a
# negative init and widen sigmaP so the signal locks onto the data peak position.
tnpParNomFitByBin.update(params_for_bins(
    tnpParNomFit,
    (16, 18, 23),
    "meanP[-1.0,-4.0,1.0]",
    "sigmaP[1.8,0.6,4.0]",
))

tnpParAltSigFitByBin = {}
tnpParAltSigFitByBin.update(params_for_bins(
    tnpParAltSigFit,
    (0, 1, 2, 3, 4, 5, 6, 10, 12, 15),
    "meanP[-25.0,-40.0,5.0]",
    "sigmaP[7.0,2.0,16.0]",
    "sigmaP_2[3.0,0.6,12.0]",
    "alphaP[1.6,0.5,4.5]",
    "nP[1.0,-2.0,10.0]",
    "sosP[2.0,0.1,10.0]",
    "meanF[-2.0,-8.0,5.0]",
    "sigmaF[4.0,0.8,9.0]",
    "sigmaF_2[1.2,0.4,7.0]",
    "alphaF[1.6,0.8,4.5]",
    "nF[0.6,0.0,8.0]",
    "sosF[1.2,0.1,7.0]",
    "acmsP[90.,65.,115.]",
    "betaP[0.025,0.001,0.08]",
    "gammaP[0.04,0.001,0.8]",
    "acmsF[78.,45.,100.]",
    "betaF[0.02,0.001,0.08]",
    "gammaF[0.04,0.001,0.8]",
))
tnpParAltSigFitByBin.update(params_for_bins(
    tnpParAltSigFit,
    (5, 7, 9, 11, 12, 15),
    "meanP[-25.0,-40.0,5.0]",
    "sigmaP[7.0,2.0,16.0]",
    "sigmaP_2[3.0,0.6,12.0]",
    "alphaP[1.6,0.5,4.5]",
    "nP[1.0,-2.0,10.0]",
    "sosP[2.0,0.1,10.0]",
    "meanF[-2.0,-8.0,5.0]",
    "sigmaF[4.0,0.8,9.0]",
    "sigmaF_2[1.2,0.4,7.0]",
    "alphaF[1.6,0.8,4.5]",
    "nF[0.6,0.0,8.0]",
    "sosF[1.2,0.1,7.0]",
    "acmsP[58.,35.,78.]",
    "betaP[0.02,0.001,0.06]",
    "gammaP[0.035,0.001,0.8]",
    "acmsF[78.,45.,100.]",
    "betaF[0.02,0.001,0.08]",
    "gammaF[0.04,0.001,0.8]",
))
tnpParAltSigFitByBin.update(params_for_bins(
    tnpParAltSigFit,
    (17, 18, 19, 20, 21, 31),
    "meanP[-0.8,-6.0,5.0]",
    "sigmaP[2.5,0.8,6.5]",
    "sigmaP_2[1.2,0.4,6.0]",
    "sosP[0.8,0.1,5.0]",
    "meanF[-0.8,-6.0,5.0]",
    "sigmaF[2.8,0.8,7.0]",
    "sigmaF_2[1.0,0.4,6.0]",
    "sosF[0.8,0.1,5.0]",
    "acmsP[58.,40.,75.]",
    "betaP[0.02,0.001,0.06]",
    "gammaP[0.04,0.001,0.8]",
    "acmsF[58.,40.,75.]",
    "betaF[0.02,0.001,0.06]",
    "gammaF[0.04,0.001,0.8]",
))
tnpParAltSigFitByBin.update(params_for_bins(
    tnpParAltSigFit,
    (17, 18),
    "meanP[-0.6,-5.0,4.0]",
    "sigmaP[1.8,0.7,4.5]",
    "sigmaP_2[1.0,0.4,3.5]",
    "sosP[0.6,0.0,2.5]",
    "meanF[-0.8,-6.0,5.0]",
    "sigmaF[2.4,0.8,6.0]",
    "sigmaF_2[1.0,0.4,5.0]",
    "sosF[0.7,0.0,3.0]",
    "acmsP[55.,38.,72.]",
    "betaP[0.018,0.001,0.05]",
    "gammaP[0.035,0.001,0.7]",
    "acmsF[55.,38.,72.]",
    "betaF[0.018,0.001,0.05]",
    "gammaF[0.035,0.001,0.7]",
))
tnpParAltSigFitByBin[21] = params_with_updates(
    tnpParAltSigFitByBin[21],
    "sigmaP[3.4,0.8,8.0]",
    "sigmaP_2[1.6,0.4,6.5]",
    "sosP[1.1,0.0,5.5]",
    # failing leg over-broad: sigmaF railed at 7 and smeared over the 78 shoulder.
    # Cap it lower so the signal focuses on the 88 peak.
    "sigmaF[3.0,1.0,5.0]",
    "sigmaF_2[1.2,0.4,4.0]",
    "sosF[0.7,0.0,3.0]",
)
# bin18: both legs over-peaked (CB core stuck too narrow at its init -> red spike
# overshoots the broader data Z peak). Widen the core inits/floors so the model
# peak height matches data; free the soft-core fraction.
tnpParAltSigFitByBin[18] = params_with_updates(
    tnpParAltSigFitByBin[18],
    "sigmaP[2.8,1.6,5.5]",
    "sigmaP_2[1.8,0.9,5.0]",
    "sosP[0.8,0.0,3.0]",
    "sigmaF[3.0,1.2,5.0]",
    "sigmaF_2[1.4,0.6,4.0]",
    "sosF[0.7,0.0,3.0]",
)
# bin17: passing CB core stuck too narrow at init -> red over-peaks the data Z peak.
# Same widen-core fix as bin18.
tnpParAltSigFitByBin[17] = params_with_updates(
    tnpParAltSigFitByBin[17],
    "sigmaP[2.8,1.6,5.5]",
    "sigmaP_2[1.8,0.9,5.0]",
    "sosP[0.8,0.0,3.0]",
)
# bin20: failing leg has a 78-GeV shoulder + 88-GeV peak; the single narrow signal
# misses the shoulder. Add a wide secondary component (large sigmaF_2) as a pedestal
# under the peak so the 78 region is covered, keeping a narrow core for the 88 peak.
tnpParAltSigFitByBin[20] = params_with_updates(
    tnpParAltSigFitByBin[20],
    "meanF[-0.8,-2.5,1.0]",
    "sigmaF[2.0,1.0,3.5]",
    "sigmaF_2[4.5,2.0,7.0]",
    "sosF[0.8,0.0,3.0]",
)
# bin21: failing signal was left-shifted (meanF~-2.1) and too broad on the rising
# edge. Pull meanF back toward the peak and split into a narrow core + wide pedestal.
tnpParAltSigFitByBin[21] = params_with_updates(
    tnpParAltSigFitByBin[21],
    "meanF[-0.8,-2.2,0.8]",
    "sigmaF[2.2,1.0,3.5]",
    "sigmaF_2[4.5,2.0,7.0]",
    "sosF[0.8,0.0,3.0]",
)

tnpParAltBkgFitByBin = {
    5: params_with_updates(
        tnpParAltBkgFit,
        "meanP[-2.0,-6.0,5.0]",
        "sigmaP[3.0,0.8,7.0]",
        "alphaP[-0.01,-0.06,0.03]",
        "meanF[-2.0,-6.0,5.0]",
        "sigmaF[3.5,0.8,8.0]",
        "alphaF[-0.01,-0.06,0.03]",
    ),
}
tnpParAltBkgFitByBin.update(params_for_bins(
    tnpParAltBkgFit,
    (11, 12),
    "meanF[-0.8,-5.0,2.0]",
    "sigmaF[1.6,0.5,4.5]",
    "alphaF[-0.04,-0.18,-0.004]",
))
